import React from 'react';

export const DoctorEmblemSvg: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => (
  <svg
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect
      x="2"
      y="2"
      width="44"
      height="44"
      rx="12"
      className="fill-[#0F5257] stroke-[#C5A059]"
      strokeWidth="1.5"
    />
    {/* Subtle Golden Ratio Arch & Crown Silhouette */}
    <path
      d="M15 17C15 13.5 18.2 11 21.5 12.2C23.1 12.8 24.9 12.8 26.5 12.2C29.8 11 33 13.5 33 17C33 22.5 30.8 27.5 29.2 33.2C28.6 35.1 26.8 35.5 25.8 33.8L24.8 31.8C24.4 31 23.6 31 23.2 31.8L22.2 33.8C21.2 35.5 19.4 35.1 18.8 33.2C17.2 27.5 15 22.5 15 17Z"
      stroke="#FAF8F5"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Precision Golden Caliper Line */}
    <path
      d="M11 24H37"
      stroke="#C5A059"
      strokeWidth="1.2"
      strokeDasharray="2 2"
      strokeLinecap="round"
    />
    <circle cx="24" cy="18.5" r="2" fill="#C5A059" />
  </svg>
);

export const SpecialtyAnatomyIcon: React.FC<{
  type: 'veneer' | 'implant' | 'dsd' | 'laser' | 'aligner' | 'micro';
  className?: string;
}> = ({ type, className = 'w-7 h-7' }) => {
  switch (type) {
    case 'veneer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          {/* Natural Tooth Base */}
          <path
            d="M9 10C9 7.2 11.4 5.5 14 6.4C15.3 6.8 16.7 6.8 18 6.4C20.6 5.5 23 7.2 23 10C23 14.8 21.2 19.2 19.8 24.2C19.3 25.8 17.8 26 17 24.5L16.4 23.2C16.1 22.6 15.9 22.6 15.6 23.2L15 24.5C14.2 26 12.7 25.8 12.2 24.2C10.8 19.2 9 14.8 9 10Z"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          {/* Ultra-thin Veneer Shell Overlay */}
          <path
            d="M12.5 8.5C14.8 9.2 17.2 9.2 19.5 8.5C19.5 13 18.6 17 17.5 20.5"
            stroke="#C5A059"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path d="M25 7L27 5M26 11H28.5" stroke="#C5A059" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case 'implant':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          {/* Crown */}
          <path
            d="M10 9.5C10 7 12.2 5.5 14.5 6.2C15.5 6.5 16.5 6.5 17.5 6.2C19.8 5.5 22 7 22 9.5C22 12.2 20.5 14.5 19 15.5H13C11.5 14.5 10 12.2 10 9.5Z"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          {/* Titanium Fixture Threads */}
          <path
            d="M13.5 15.5L14.2 25.5C14.3 26.6 15.1 27.2 16 27.2C16.9 27.2 17.7 26.6 17.8 25.5L18.5 15.5"
            stroke="#C5A059"
            strokeWidth="1.6"
          />
          <path
            d="M12.8 18.5H19.2M13.2 21.5H18.8M13.8 24.5H18.2"
            stroke="#C5A059"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'laser':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          {/* Gingival Scallop Line */}
          <path
            d="M4 15C7.5 15 8.5 10 12 10C15.5 10 16 15 16 15C16 15 16.5 10 20 10C23.5 10 24.5 15 28 15"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          {/* Tooth Silhouette */}
          <path
            d="M8 14.5V21C8 23.5 9.8 25 12 25C14.2 25 16 23.5 16 21V15M16 15V21C16 23.5 17.8 25 20 25C22.2 25 24 23.5 24 21V14.5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          {/* Precision Laser Beam */}
          <path d="M23 4L17 11" stroke="#C5A059" strokeWidth="1.8" strokeLinecap="round" />
          <circle cx="16.5" cy="11.5" r="2" fill="#C5A059" />
        </svg>
      );
    case 'micro':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          <circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="1.6" />
          <circle
            cx="16"
            cy="16"
            r="6"
            stroke="#C5A059"
            strokeWidth="1.4"
            strokeDasharray="3 2"
          />
          <path
            d="M16 3V7M16 25V29M3 16H7M25 16H29"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <circle cx="16" cy="16" r="2" fill="#C5A059" />
        </svg>
      );
    case 'aligner':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          {/* Arch Curve */}
          <path
            d="M6 21C6 12.7 10.5 7 16 7C21.5 7 26 12.7 26 21"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M9.5 22C9.5 15.5 12.4 11 16 11C19.6 11 22.5 15.5 22.5 22"
            stroke="#C5A059"
            strokeWidth="1.6"
            strokeDasharray="2.5 2.5"
            strokeLinecap="round"
          />
          <circle cx="16" cy="9" r="1.8" fill="#C5A059" />
          <circle cx="11.5" cy="12" r="1.5" fill="currentColor" />
          <circle cx="20.5" cy="12" r="1.5" fill="currentColor" />
        </svg>
      );
    case 'dsd':
    default:
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className}>
          {/* Golden Ratio Smile Grid */}
          <rect
            x="4"
            y="8"
            width="24"
            height="16"
            rx="4"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          <path
            d="M8 15.5C11 19.5 21 19.5 24 15.5"
            stroke="#C5A059"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path
            d="M16 8V24M11.5 8V24M20.5 8V24"
            stroke="currentColor"
            strokeWidth="1.1"
            strokeDasharray="2 2"
          />
        </svg>
      );
  }
};
