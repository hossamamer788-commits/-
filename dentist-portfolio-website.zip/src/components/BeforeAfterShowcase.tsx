import React, { useState, useRef, useCallback } from 'react';
import {
  Sparkles,
  SlidersHorizontal,
  CheckCircle2,
  Clock,
  Layers,
  Award,
  ArrowLeft,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import {
  CLINICAL_CASES,
  CaseCategory,
  ClinicalCase,
  SHADE_PREVIEW_OPTIONS,
} from '../data/portfolioData';

interface BeforeAfterShowcaseProps {
  onSelectCaseForBooking: (serviceHint: string, noteHint: string) => void;
}

export const BeforeAfterShowcase: React.FC<BeforeAfterShowcaseProps> = ({
  onSelectCaseForBooking,
}) => {
  const [activeCategory, setActiveCategory] = useState<CaseCategory>('all');
  const [selectedCaseId, setSelectedCaseId] = useState<string>(CLINICAL_CASES[0].id);
  const [sliderPosition, setSliderPosition] = useState<number>(52);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [selectedShadeCode, setSelectedShadeCode] = useState<string>('BL2');

  const containerRef = useRef<HTMLDivElement | null>(null);

  const filteredCases =
    activeCategory === 'all'
      ? CLINICAL_CASES
      : CLINICAL_CASES.filter((c) => c.category === activeCategory);

  const activeCase: ClinicalCase =
    filteredCases.find((c) => c.id === selectedCaseId) || filteredCases[0] || CLINICAL_CASES[0];

  const activeShade =
    SHADE_PREVIEW_OPTIONS.find((s) => s.code === selectedShadeCode) || SHADE_PREVIEW_OPTIONS[1];

  const handleCategoryChange = (cat: CaseCategory) => {
    setActiveCategory(cat);
    const nextList =
      cat === 'all' ? CLINICAL_CASES : CLINICAL_CASES.filter((c) => c.category === cat);
    if (nextList.length > 0) {
      setSelectedCaseId(nextList[0].id);
      setSliderPosition(50);
    }
  };

  const updateSliderFromClientX = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percentage = (x / rect.width) * 100;
    setSliderPosition(Math.min(96, Math.max(4, percentage)));
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    updateSliderFromClientX(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    updateSliderFromClientX(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isDragging) {
      setIsDragging(false);
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  const categories: { id: CaseCategory; label: string; count: number }[] = [
    { id: 'all', label: 'جميع الحالات الموثقة', count: CLINICAL_CASES.length },
    {
      id: 'veneers',
      label: 'هوليود سمايل وفينير',
      count: CLINICAL_CASES.filter((c) => c.category === 'veneers').length,
    },
    {
      id: 'implants',
      label: 'زراعة الأسنان الفورية',
      count: CLINICAL_CASES.filter((c) => c.category === 'implants').length,
    },
    {
      id: 'gingiva',
      label: 'تجميل اللثة والتركيبات',
      count: CLINICAL_CASES.filter((c) => c.category === 'gingiva').length,
    },
  ];

  return (
    <section
      id="cases"
      className="relative bg-[#0D1B1E] text-[#F9FAFB] py-24 lg:py-32 overflow-hidden clinical-grid-bg"
    >
      {/* Subtle Ambient Top Glow */}
      <div
        className="pointer-events-none absolute -top-40 right-1/4 w-[520px] h-[520px] rounded-full opacity-15 blur-3xl"
        style={{
          background: 'radial-gradient(circle, #C5A059 0%, #0F5257 60%, transparent 100%)',
        }}
      />

      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 pb-12 border-b border-white/12">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/12 text-[#C5A059] text-xs font-medium mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="font-mono-tech tracking-wider uppercase">
                CLINICAL PORTFOLIO // 100% UNEDITED DENTAL MACRO
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-bold text-white leading-[1.2] font-heading">
              مختبر التحول السريري:{' '}
              <span className="text-[#C5A059]">نتائج حقيقية تحت عدسة الماكرو</span>
            </h2>
            <p className="mt-4 text-slate-300 text-base sm:text-lg leading-relaxed">
              جميع الصور المعروضة موثقة من داخل عيادة د. حسام أشرف بإضاءة الاستوديو الجراحية دون أي
              تعديل رقمي، لتعاين بنفسك دقة انطباق الحواف وشفافية المينا الطبيعية.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleCategoryChange(cat.id)}
                  className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                    isActive
                      ? 'bg-[#C5A059] text-[#0D1B1E] font-bold shadow-lg shadow-[#C5A059]/20'
                      : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span
                    className={`text-xs px-1.5 py-0.5 rounded-md font-mono-tech ${
                      isActive ? 'bg-[#0D1B1E]/20 text-[#0D1B1E]' : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Case Switcher Tabs when multiple cases exist */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          {CLINICAL_CASES.map((item, idx) => {
            const isSelected = item.id === activeCase.id;
            const isDimmed =
              activeCategory !== 'all' && item.category !== activeCategory;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveCategory('all');
                  setSelectedCaseId(item.id);
                  setSliderPosition(50);
                }}
                className={`text-right p-4 rounded-2xl border transition-all duration-200 cursor-pointer flex items-start justify-between gap-3 ${
                  isSelected
                    ? 'bg-white/10 border-[#C5A059] shadow-lg'
                    : isDimmed
                    ? 'bg-white/[0.02] border-white/5 opacity-50 hover:opacity-90'
                    : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.07]'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tech text-xs text-[#C5A059]">
                      0{idx + 1} // {item.code.split('// ')[1]}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded-full bg-white/10 text-slate-200">
                      {item.categoryLabel}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-white line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono-tech">{item.shadeTransition}</p>
                </div>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1 ${
                    isSelected
                      ? 'bg-[#C5A059] text-[#0D1B1E]'
                      : 'bg-white/10 text-slate-300'
                  }`}
                >
                  <Eye className="w-4 h-4" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Main Interactive Split Comparison Stage */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Interactive Image Comparison Column (7 cols on desktop) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="relative rounded-2xl overflow-hidden border border-white/15 bg-[#071012] shadow-2xl select-none">
              {/* Top Technical Bar inside frame */}
              <div className="flex items-center justify-between px-4 py-3 bg-[#091417]/90 border-b border-white/10 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-mono-tech text-slate-300">{activeCase.code}</span>
                </div>
                <div className="flex items-center gap-2 text-[#C5A059] font-medium">
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>اسحب المؤشر يميناً ويساراً للمقارنة المباشرة</span>
                </div>
              </div>

              {/* Interactive Viewport */}
              <div
                ref={containerRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                className="relative w-full aspect-[16/10] sm:aspect-[16/9] overflow-hidden ew-resize-cursor touch-none"
                dir="ltr"
              >
                {/* Base Layer: AFTER Image (Full width) */}
                <img
                  src={activeCase.afterImage}
                  alt={`بعد العلاج - ${activeCase.title}`}
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                  draggable={false}
                />

                {/* Overlay Layer: BEFORE Image clipped by sliderPosition */}
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{
                    clipPath: `inset(0 ${100 - sliderPosition}% 0 0)`,
                  }}
                >
                  <img
                    src={activeCase.beforeImage}
                    alt={`قبل العلاج - ${activeCase.title}`}
                    className="absolute inset-0 w-full h-full object-cover"
                    draggable={false}
                  />
                </div>

                {/* Corner Labels: BEFORE (Left) & AFTER (Right) */}
                <div className="absolute top-4 left-4 z-20 pointer-events-none">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/75 backdrop-blur-md border border-white/15 text-xs font-bold text-slate-200">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    قبل الإجراء (Before)
                  </span>
                </div>

                <div className="absolute top-4 right-4 z-20 pointer-events-none">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0F5257]/90 backdrop-blur-md border border-[#C5A059]/50 text-xs font-bold text-white shadow-lg">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    بعد الإجراء (After)
                  </span>
                </div>

                {/* Vertical Divider Hairline & Tactile Handle */}
                <div
                  className="absolute top-0 bottom-0 z-30 pointer-events-none"
                  style={{ left: `${sliderPosition}%` }}
                >
                  <div className="absolute top-0 bottom-0 -left-[1px] w-[2px] bg-[#C5A059] shadow-[0_0_15px_rgba(197,160,89,0.9)]" />
                  <div
                    className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-[#FAF8F5] text-[#0F5257] border-2 border-[#C5A059] shadow-2xl flex items-center justify-center transition-transform duration-150 ${
                      isDragging ? 'scale-110 ring-4 ring-[#C5A059]/30' : 'hover:scale-105'
                    }`}
                  >
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      className="w-5 h-5 stroke-current"
                      strokeWidth="2.2"
                    >
                      <path d="M8 7L3 12L8 17" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M16 7L21 12L16 17" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                </div>

                {/* Bottom Subtle Readout */}
                <div
                  dir="rtl"
                  className="absolute bottom-3 inset-x-3 z-20 flex flex-wrap items-center justify-between gap-2 px-3.5 py-2 rounded-xl bg-black/65 backdrop-blur-md border border-white/10 text-xs pointer-events-none"
                >
                  <span className="text-slate-200 font-medium">
                    المادة المستخدمة:{' '}
                    <strong className="font-mono-tech text-[#C5A059]">
                      {activeCase.materialUsed}
                    </strong>
                  </span>
                  <span className="font-mono-tech text-emerald-300">
                    درجة اللون: {activeCase.shadeTransition}
                  </span>
                </div>
              </div>

              {/* Quick Position Preset Controls + Accessible Range Input */}
              <div className="px-4 py-3 bg-[#091417] border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSliderPosition(92)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      sliderPosition > 75
                        ? 'bg-[#C5A059] text-[#0D1B1E] font-bold'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    عرض قبل الإجراء
                  </button>
                  <button
                    type="button"
                    onClick={() => setSliderPosition(50)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      sliderPosition >= 35 && sliderPosition <= 65
                        ? 'bg-[#C5A059] text-[#0D1B1E] font-bold'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    مقارنة منتصف ٥٠/٥٠
                  </button>
                  <button
                    type="button"
                    onClick={() => setSliderPosition(8)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      sliderPosition < 25
                        ? 'bg-[#C5A059] text-[#0D1B1E] font-bold'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    عرض النتيجة النهائية
                  </button>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>تصوير ماكرو سريري موثق بدون فلاتر</span>
                </div>
              </div>
            </div>

            {/* Precision Metrics Strip */}
            <div className="grid grid-cols-3 gap-3">
              {activeCase.precisionMetrics.map((metric, index) => (
                <div
                  key={index}
                  className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 text-center"
                >
                  <div className="font-mono-tech text-base sm:text-lg font-bold text-[#C5A059]">
                    {metric.value}
                  </div>
                  <div className="text-xs text-slate-300 mt-1">{metric.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Clinical Case Details Column (5 cols on desktop) */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-white/[0.04] border border-white/12 rounded-2xl p-6 sm:p-8 backdrop-blur-md">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-white/10">
                <span className="px-3 py-1 rounded-full bg-[#0F5257] text-emerald-200 text-xs font-semibold">
                  {activeCase.categoryLabel}
                </span>
                <div className="flex items-center gap-3 text-xs text-slate-300 font-mono-tech">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                    {activeCase.sessionsCount} ({activeCase.durationDays})
                  </span>
                </div>
              </div>

              <h3 className="mt-5 text-xl sm:text-2xl font-bold text-white leading-snug font-heading">
                {activeCase.title}
              </h3>

              {/* Chief Complaint & Clinical Protocol */}
              <div className="mt-6 space-y-4">
                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/8">
                  <div className="text-xs font-bold text-[#C5A059] uppercase tracking-wider mb-1.5">
                    التشخيص المبدئي قبل العلاج:
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {activeCase.chiefComplaint}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0F5257]/25 border border-emerald-500/20">
                  <div className="text-xs font-bold text-emerald-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    البروتوكول السريري المطبق:
                  </div>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {activeCase.clinicalApproach}
                  </p>
                </div>
              </div>

              {/* Technical Specs Pill List */}
              <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white/[0.03] border border-white/8">
                  <Layers className="w-4 h-4 text-[#C5A059] shrink-0" />
                  <div>
                    <span className="text-slate-400 block">الخامة المعتمدة</span>
                    <span className="font-mono-tech text-white font-semibold">
                      {activeCase.materialUsed}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white/[0.03] border border-white/8">
                  <Award className="w-4 h-4 text-[#C5A059] shrink-0" />
                  <div>
                    <span className="text-slate-400 block">التحول اللوني</span>
                    <span className="font-mono-tech text-white font-semibold">
                      {activeCase.shadeTransition}
                    </span>
                  </div>
                </div>
              </div>

              {/* Patient Quote */}
              <blockquote className="mt-6 p-4 rounded-xl bg-gradient-to-l from-[#C5A059]/15 to-transparent border-r-2 border-[#C5A059]">
                <p className="text-xs sm:text-sm text-slate-200 italic leading-relaxed">
                  «{activeCase.patientFeedback}»
                </p>
                <footer className="mt-2 text-xs font-semibold text-[#C5A059]">
                  — {activeCase.patientInitials}
                </footer>
              </blockquote>
            </div>

            {/* CTA to book similar case */}
            <div className="mt-6 pt-5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={() =>
                  onSelectCaseForBooking(
                    activeCase.categoryLabel,
                    `أرغب في استشارة لحالة مشابهة لـ (${activeCase.code}: ${activeCase.title})`
                  )
                }
                className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#C5A059] hover:bg-[#d4b06a] text-[#0D1B1E] font-bold text-sm transition shadow-lg shadow-[#C5A059]/20 cursor-pointer"
              >
                <span>احجز استشارة لحالة مماثلة</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Interactive VITA Porcelain Shade & Translucency Guide */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-white/[0.04] border border-white/12">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="max-w-xl">
              <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-wider">
                INTERACTIVE VITA SHADE CALIBRATOR // دليل درجات البياض الطبيعي
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white mt-1 font-heading">
                كيف نختار درجة بياض ابتسامتك؟ جرب دليل الدرجات الخزفية
              </h3>
              <p className="text-sm text-slate-300 mt-1.5">
                لا نستخدم لوناً واحداً جامداً؛ بل نصمم تدرجاً ضوئياً يحاكي شفافية المينا الطبيعية
                ويتناغم مع لون البشرة وبياض العين.
              </p>
            </div>

            {/* Shade Selector Swatches */}
            <div className="flex flex-wrap items-center gap-3">
              {SHADE_PREVIEW_OPTIONS.map((shade) => {
                const isSelected = shade.code === selectedShadeCode;
                return (
                  <button
                    key={shade.code}
                    type="button"
                    onClick={() => setSelectedShadeCode(shade.code)}
                    className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white/15 border-[#C5A059] shadow-md scale-[1.02]'
                        : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {/* Porcelain Tooth Swatch Pill */}
                    <span
                      className="w-6 h-8 rounded-t-md rounded-b-xl border shadow-inner block shrink-0"
                      style={{
                        backgroundColor: shade.hexPreview,
                        borderColor: shade.borderHex,
                      }}
                    />
                    <div className="text-right">
                      <span className="font-mono-tech text-xs font-bold text-white block">
                        {shade.code}
                      </span>
                      <span className="text-[11px] text-slate-300 block">
                        {shade.nameAr.split(' (')[0]}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Shade Detail Readout */}
          <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-8 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-14 rounded-t-lg rounded-b-2xl border-2 shadow-lg shrink-0 relative overflow-hidden"
                  style={{
                    backgroundColor: activeShade.hexPreview,
                    borderColor: activeShade.borderHex,
                  }}
                >
                  {/* Simulated incisal edge translucency */}
                  <div className="absolute bottom-0 inset-x-0 h-3 bg-gradient-to-t from-sky-200/40 to-transparent" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tech text-sm font-bold text-[#C5A059]">
                      {activeShade.nameEn}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white">{activeShade.nameAr}</h4>
                  <p className="text-xs text-emerald-300 mt-0.5">{activeShade.translucency}</p>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 sm:border-r sm:border-white/15 sm:pr-4 leading-relaxed">
                {activeShade.recommendedFor}
              </p>
            </div>

            <div className="md:col-span-4 flex justify-end">
              <button
                type="button"
                onClick={() =>
                  onSelectCaseForBooking(
                    'هوليود سمايل وفينير',
                    `أرغب في تجربة درجة اللون (${activeShade.code} - ${activeShade.nameAr}) أثناء جلسة تصميم الابتسامة الرقمي`
                  )
                }
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-[#C5A059]/50 text-xs font-semibold text-white transition cursor-pointer"
              >
                اطلب معاينة درجة {activeShade.code} في استشارتك ←
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
