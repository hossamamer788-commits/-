import React from 'react';
import {
  Award,
  GraduationCap,
  ShieldCheck,
  Microscope,
  CheckCircle2,
  MapPin,
  Cpu,
  Quote,
} from 'lucide-react';
import {
  CREDENTIALS,
  DOCTOR_INFO,
  PATIENT_JOURNEY,
} from '../data/portfolioData';

export const AboutAndJourney: React.FC = () => {
  return (
    <>
      {/* About Dr. Hossam & Academic Credentials Section */}
      <section
        id="about"
        className="py-24 lg:py-32 bg-[#F2EFE9] border-y border-[#E6E2DA] relative overflow-hidden"
      >
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Right Column: Doctor Philosophy & Credentials (7 Cols) */}
            <div className="lg:col-span-7 space-y-8">
              <div>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-[#E6E2DA] text-[#0F5257] text-xs font-bold mb-4">
                  <GraduationCap className="w-4 h-4 text-[#C5A059]" />
                  <span className="font-mono-tech uppercase tracking-wider">
                    ACADEMIC EXCELLENCE & BIOGRAPHY // المسيرة العلمية
                  </span>
                </div>
                <h2 className="text-3xl sm:text-4xl lg:text-[2.6rem] font-bold text-[#111827] leading-[1.2] font-heading">
                  د. حسام أشرف:{' '}
                  <span className="text-[#0F5257]">
                    حيث تلتقي الدقة الأكاديمية بالحس التجميلي الرفيع
                  </span>
                </h2>
                <p className="mt-4 text-[#4B5563] text-base sm:text-lg leading-relaxed">
                  كرّس الدكتور حسام أشرف مسيرته المهنية والأكاديمية لتطوير مفهوم «طب الأسنان التجميلي
                  الحيوي غير الجائر»، مؤمناً بأن كل ابتسامة لها بصمة هندسية خاصة ترتبط بتقاسيم الوجه
                  وديناميكية النطق والابتسام.
                </p>
              </div>

              {/* Signature Philosophy Quote Box */}
              <div className="p-6 sm:p-7 rounded-2xl bg-white border border-[#E6E2DA] shadow-sm relative">
                <Quote className="w-8 h-8 text-[#C5A059]/30 absolute top-5 left-6" />
                <p className="text-base sm:text-lg font-medium text-[#111827] leading-relaxed relative z-10">
                  {DOCTOR_INFO.philosophyQuote}
                </p>
                <div className="mt-4 pt-4 border-t border-[#E6E2DA] flex items-center justify-between">
                  <div>
                    <div className="font-bold text-sm text-[#0F5257]">{DOCTOR_INFO.nameAr}</div>
                    <div className="font-mono-tech text-xs text-[#78716C]">
                      {DOCTOR_INFO.nameEn}
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-lg bg-[#FAF8F5] border border-[#E6E2DA] font-mono-tech text-xs text-[#0F5257] font-semibold">
                    AACD • ITI • DSD MASTER
                  </span>
                </div>
              </div>

              {/* Credentials Grid */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-[#78716C] uppercase tracking-wider">
                  الزمالات والشهادات العلمية المعتمدة:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {CREDENTIALS.map((cred) => (
                    <div
                      key={cred.code}
                      className="p-4 rounded-xl bg-white border border-[#E6E2DA] hover:border-[#C5A059] transition-colors flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 text-xs font-mono-tech text-[#C5A059] font-semibold">
                          <span>{cred.year}</span>
                          <span>{cred.code.split('// ')[1]}</span>
                        </div>
                        <h4 className="mt-2 font-bold text-[#111827] text-sm sm:text-base leading-snug">
                          {cred.title}
                        </h4>
                      </div>
                      <div className="mt-3 pt-2.5 border-t border-[#E6E2DA]/60 flex items-center justify-between text-xs text-[#4B5563]">
                        <span className="truncate">{cred.institution}</span>
                        <span className="inline-flex items-center gap-1 text-[#78716C] shrink-0">
                          <MapPin className="w-3 h-3 text-[#0F5257]" />
                          {cred.location}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Left Column: Architectural Clinic Studio Card & Sterilization Standards (5 Cols) */}
            <div className="lg:col-span-5 space-y-6">
              <div className="rounded-2xl overflow-hidden bg-white border border-[#E6E2DA] shadow-xl">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src="/images/clinic-interior.jpg"
                    alt="استوديو وعيادة الدكتور حسام أشرف الرقمية"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D1B1E]/80 via-transparent to-transparent" />
                  <div className="absolute bottom-4 inset-x-4 flex items-end justify-between text-white">
                    <div>
                      <span className="px-2.5 py-1 rounded-md bg-[#C5A059] text-[#0D1B1E] font-mono-tech text-[11px] font-bold">
                        SWISS CLINICAL SANCTUARY
                      </span>
                      <h3 className="mt-1.5 text-lg font-bold">
                        بيئة استشفائية هادئة بمعايير أوروبية
                      </h3>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <p className="text-sm text-[#4B5563] leading-relaxed">
                    صُممت العيادة لتزيل أي شعور بالتوتر التقليدي؛ إضاءة نهارية مريحة، عزل صوتي كامل،
                    وأحدث تقنيات المسح الرقمي ثلاثي الأبعاد والتخدير الإلكتروني غير المؤلم.
                  </p>

                  <div className="grid grid-cols-1 gap-3 pt-2">
                    <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA]">
                      <ShieldCheck className="w-5 h-5 text-[#0F5257] shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-[#111827]">
                          بروتوكول تعقيم أوروبي صارم (Class-B Autoclave)
                        </h4>
                        <p className="text-xs text-[#4B5563] mt-0.5">
                          تعقيم مغلف ومؤرشف بالباركود لكل مريض مع أدوات استخدام فردي ١٠٠٪.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA]">
                      <Microscope className="w-5 h-5 text-[#C5A059] shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-[#111827]">
                          تكبير بصري ومجهري دقيق (16x Magnification)
                        </h4>
                        <p className="text-xs text-[#4B5563] mt-0.5">
                          لضمان عدم المساس بطبقة المينا السليمة وتحقيق انطباق مثالي للعدسات.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA]">
                      <Cpu className="w-5 h-5 text-[#0F5257] shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-[#111827]">
                          مختبر رقمي متكامل (CAD/CAM & 3Shape Trios)
                        </h4>
                        <p className="text-xs text-[#4B5563] mt-0.5">
                          مسح ضوئي ملون للفكين خلال دقائق بدلاً من المعجون التقليدي.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4-Step Patient Journey & Clinical Protocol Timeline */}
      <section id="journey" className="py-24 lg:py-32 bg-[#FAF8F5]">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E0F2F1] text-[#0F5257] text-xs font-bold mb-4">
              <Award className="w-3.5 h-3.5" />
              <span className="font-mono-tech uppercase tracking-wider">
                THE 4-STEP CLINICAL JOURNEY // خطوات رحلتك العلاجية
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#111827] leading-[1.2] font-heading">
              منهجية واضحة تضمن لك{' '}
              <span className="text-[#0F5257]">رؤية النتيجة قبل البدء</span>
            </h2>
            <p className="mt-4 text-[#4B5563] text-base sm:text-lg leading-relaxed">
              لا نترك مجالاً للمفاجآت في تجميل وزراعة الأسنان؛ كل خطوة مخططة رقمياً وتشاركنا القرار
              فيها بكل شفافية واطمئنان.
            </p>
          </div>

          {/* 4 Steps Grid */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
            {PATIENT_JOURNEY.map((step) => (
              <div
                key={step.stepNumber}
                className="rounded-2xl bg-white border border-[#E6E2DA] p-6 sm:p-7 flex flex-col justify-between relative group hover:border-[#0F5257] transition-all duration-300 shadow-[0_12px_30px_-15px_rgba(15,82,87,0.06)]"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-5">
                    <span className="w-12 h-12 rounded-2xl bg-[#0F5257] text-white font-mono-tech text-lg font-bold flex items-center justify-center shadow-md group-hover:bg-[#C5A059] group-hover:text-[#0D1B1E] transition-colors">
                      {step.stepNumber}
                    </span>
                    <span className="px-2.5 py-1 rounded-full bg-[#F2EFE9] text-[#4B5563] text-[11px] font-semibold">
                      {step.durationBadge}
                    </span>
                  </div>

                  <span className="font-latin text-xs font-semibold text-[#C5A059] block">
                    {step.subtitleEn}
                  </span>
                  <h3 className="mt-1 text-lg sm:text-xl font-bold text-[#111827] leading-snug font-heading">
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm text-[#4B5563] leading-relaxed">
                    {step.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E6E2DA] flex items-start gap-2 text-xs text-[#0F5257] font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#0F5257] shrink-0 mt-0.5" />
                  <span>المخرج: {step.deliverable}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};
