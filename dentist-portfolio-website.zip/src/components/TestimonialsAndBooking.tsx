import React, { useState, useEffect } from 'react';
import {
  Star,
  ShieldCheck,
  Calendar,
  Phone,
  MapPin,
  Clock,
  MessageCircle,
  CheckCircle2,
  Send,
  Sparkles,
} from 'lucide-react';
import { DOCTOR_INFO, TESTIMONIALS } from '../data/portfolioData';

interface TestimonialsAndBookingProps {
  preselectedService: string;
  preselectedNote: string;
}

export const TestimonialsAndBooking: React.FC<TestimonialsAndBookingProps> = ({
  preselectedService,
  preselectedNote,
}) => {
  const [patientName, setPatientName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedService, setSelectedService] = useState(
    'تصميم الابتسامة الرقمي وعدسات الإيماكس (DSD & Veneers)'
  );
  const [selectedBranch, setSelectedBranch] = useState('فرع التجمع الخامس — شارع التسعين الشمالي');
  const [preferredTime, setPreferredTime] = useState('الفترة المسائية (٥:٠٠ م – ٩:٣٠ م)');
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (preselectedService) {
      setSelectedService(preselectedService);
    }
    if (preselectedNote) {
      setNotes(preselectedNote);
    }
  }, [preselectedService, preselectedNote]);

  const serviceOptions = [
    'تصميم الابتسامة الرقمي وعدسات الإيماكس (DSD & Veneers)',
    'هوليود سمايل وفينير',
    'زراعة الأسنان الفورية الموجهة بالكمبيوتر',
    'تجميل اللثة والتركيبات',
    'تجميل وتوريد اللثة بالليزر الضوئي',
    'التركيبات الرقمية والحشوات التجميلية الحيوية',
    'التقويم الشفاف الرقمي غير المرئي',
    'التبييض الكيميائي الضوئي الآمن وعلاج الحساسية',
    'كشف شامل ومسح ثلاثي الأبعاد للأسنان',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !phoneNumber.trim()) return;
    setIsSubmitted(true);
  };

  const buildWhatsAppLink = () => {
    const messageLines = [
      `مرحباً عيادة د. حسام أشرف، أرغب في تأكيد حجز استشارة طبية:`,
      `• الاسم: ${patientName || 'زائر من الموقع'}`,
      `• رقم الهاتف: ${phoneNumber || 'غير محدد'}`,
      `• التخصص المطلوب: ${selectedService}`,
      `• الفرع المفضل: ${selectedBranch}`,
      `• الموعد المفضل: ${preferredTime}`,
      notes ? `• ملاحظات إضافية: ${notes}` : '',
    ].filter(Boolean);

    const encoded = encodeURIComponent(messageLines.join('\n'));
    return `https://wa.me/${DOCTOR_INFO.whatsappNumber}?text=${encoded}`;
  };

  return (
    <>
      {/* Verified Patient Stories Section */}
      <section
        id="testimonials"
        className="py-24 lg:py-28 bg-[#F2EFE9] border-t border-[#E6E2DA]"
      >
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-[#E6E2DA]">
            <div>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-[#E6E2DA] text-[#0F5257] text-xs font-bold mb-4">
                <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                <span className="font-mono-tech uppercase tracking-wider">
                  VERIFIED PATIENT STORIES // تجارب المرضى الموثقة
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#111827] leading-[1.2] font-heading">
                ثقة نعتز بها من{' '}
                <span className="text-[#0F5257]">مرضانا في مصر والخليج</span>
              </h2>
            </div>

            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white border border-[#E6E2DA]">
              <div className="flex items-center text-[#C5A059]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <div className="text-xs">
                <strong className="font-mono-tech text-[#111827] text-sm">4.98 / 5.0</strong>
                <span className="text-[#78716C] mr-1.5">تقييم موثق من +٨٥٠ مراجعاً</span>
              </div>
            </div>
          </div>

          {/* 3-Column Testimonial Cards */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl bg-white border border-[#E6E2DA] p-7 flex flex-col justify-between shadow-[0_15px_35px_-15px_rgba(15,82,87,0.06)]"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 pb-4 border-b border-[#E6E2DA]">
                    <div className="flex items-center gap-1 text-[#C5A059]">
                      {[...Array(item.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    <span className="font-mono-tech text-[11px] text-[#0F5257] bg-[#E0F2F1] px-2.5 py-0.5 rounded-md font-semibold">
                      {item.caseCode}
                    </span>
                  </div>

                  <div className="mt-4 inline-block px-3 py-1 rounded-lg bg-[#FAF8F5] border border-[#E6E2DA] text-xs font-bold text-[#0F5257]">
                    {item.procedure}
                  </div>

                  <p className="mt-4 text-[#111827] text-sm sm:text-base leading-relaxed">
                    «{item.quote}»
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E6E2DA] flex items-center justify-between">
                  <div>
                    <div className="font-bold text-sm text-[#111827]">{item.patientName}</div>
                    <div className="text-xs text-[#78716C]">{item.profession}</div>
                  </div>
                  <span className="text-xs text-[#78716C] font-mono-tech">{item.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Appointment & Consultation Booking Section */}
      <section
        id="booking"
        className="py-24 lg:py-32 bg-[#FAF8F5] border-t border-[#E6E2DA] relative"
      >
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Right Column: Clinic Details, Branches & Direct WhatsApp Card (5 Cols) */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E0F2F1] text-[#0F5257] text-xs font-bold mb-4">
                  <Calendar className="w-3.5 h-3.5" />
                  <span className="font-mono-tech uppercase tracking-wider">
                    DIRECT CONSULTATION // حجز موعد واستشارة
                  </span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-bold text-[#111827] leading-[1.2] font-heading">
                  ابدأ خطوة التحول نحو{' '}
                  <span className="text-[#0F5257]">ابتسامة مصممة خصيصاً لك</span>
                </h2>
                <p className="mt-4 text-[#4B5563] text-base leading-relaxed">
                  احجز موعدك الآن لإجراء الفحص الرقمي وتصميم الابتسامة ثلاثي الأبعاد مع د. حسام أشرف.
                  يقوم فريق التنسيق الطبي بتأكيد الموعد خلال أقل من ٣٠ دقيقة.
                </p>
              </div>

              {/* Clinic Locations Card */}
              <div className="rounded-2xl bg-white border border-[#E6E2DA] p-6 space-y-5 shadow-sm">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#0F5257] text-white flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#C5A059] block">
                      الفرع الرئيسي — القاهرة الجديدة
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-[#111827] mt-0.5">
                      {DOCTOR_INFO.clinicAddressAr}
                    </h3>
                  </div>
                </div>

                <div className="border-t border-[#E6E2DA] pt-4 flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#F2EFE9] text-[#0F5257] flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#78716C] block">
                      فرع غرب القاهرة — الشيخ زايد
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-[#111827] mt-0.5">
                      {DOCTOR_INFO.secondaryBranchAr}
                    </h3>
                  </div>
                </div>

                <div className="border-t border-[#E6E2DA] pt-4 flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#F2EFE9] text-[#0F5257] flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#78716C] block">
                      مواعيد العمل الرسمية
                    </span>
                    <p className="text-sm font-semibold text-[#111827] mt-0.5">
                      {DOCTOR_INFO.workingHours}
                    </p>
                  </div>
                </div>

                <div className="border-t border-[#E6E2DA] pt-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#E0F2F1] text-[#0F5257] flex items-center justify-center shrink-0">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-[#78716C] block">الخط المباشر للعيادة</span>
                      <a
                        href={`tel:${DOCTOR_INFO.phoneDisplay.replace(/\s+/g, '')}`}
                        dir="ltr"
                        className="font-mono-tech text-sm sm:text-base font-bold text-[#0F5257] hover:underline"
                      >
                        {DOCTOR_INFO.phoneDisplay}
                      </a>
                    </div>
                  </div>

                  <a
                    href={buildWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F5257] hover:bg-[#0A3C40] text-white text-xs font-bold transition shadow-sm"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>تواصل عبر واتساب</span>
                  </a>
                </div>
              </div>

              {/* International / VIP Patients Notice */}
              <div className="p-5 rounded-2xl bg-[#0D1B1E] text-white border border-white/10">
                <div className="flex items-center gap-2 text-[#C5A059] text-xs font-bold mb-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>برنامج خاص للقادمين من خارج مصر (السياحة العلاجية VIP)</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  نوفر استشارة فيديو مسبقة مع د. حسام أشرف وجدولة مكثفة لإنهاء عدسات الإيماكس أو
                  الزراعة الفورية خلال ٥ إلى ٧ أيام فقط مع استقبال خاص.
                </p>
              </div>
            </div>

            {/* Left Column: Interactive Appointment Request Form (7 Cols) */}
            <div className="lg:col-span-7">
              <div className="rounded-3xl bg-white border border-[#E6E2DA] p-7 sm:p-10 shadow-[0_25px_50px_-15px_rgba(15,82,87,0.08)]">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-6 border-b border-[#E6E2DA]">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-bold text-[#111827] font-heading">
                      نموذج حجز موعد واستشارة رقمية
                    </h3>
                    <p className="text-xs sm:text-sm text-[#4B5563] mt-1">
                      املأ البيانات التالية لتحديد موعدك أو إرسال طلبك مباشرة إلى منسق المواعيد
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#E0F2F1] text-[#0F5257] text-xs font-bold">
                    استجابة سريعة خلال ٣٠ دقيقة
                  </span>
                </div>

                {isSubmitted ? (
                  <div className="py-10 text-center space-y-5">
                    <div className="w-16 h-16 rounded-full bg-[#E0F2F1] text-[#0F5257] flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-9 h-9" />
                    </div>
                    <div className="space-y-2 max-w-md mx-auto">
                      <h4 className="text-2xl font-bold text-[#111827] font-heading">
                        تم تسجيل طلب حجزك بنجاح، أ. {patientName}!
                      </h4>
                      <p className="text-sm text-[#4B5563] leading-relaxed">
                        تم تجهيز بطاقة الموعد الخاصة بك لـ{' '}
                        <strong className="text-[#0F5257]">{selectedService}</strong> في{' '}
                        <strong>{selectedBranch}</strong>.
                      </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E6E2DA] max-w-md mx-auto text-right text-xs space-y-1.5 text-[#4B5563]">
                      <div>
                        <strong className="text-[#111827]">الاسم:</strong> {patientName}
                      </div>
                      <div>
                        <strong className="text-[#111827]">رقم الهاتف:</strong>{' '}
                        <span className="font-mono-tech">{phoneNumber}</span>
                      </div>
                      <div>
                        <strong className="text-[#111827]">الخدمة:</strong> {selectedService}
                      </div>
                      <div>
                        <strong className="text-[#111827]">الفترة المفضلة:</strong> {preferredTime}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                      <a
                        href={buildWhatsAppLink()}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#0F5257] hover:bg-[#0A3C40] text-white font-bold text-sm transition shadow-lg"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>إرسال تأكيد الحجز الفوري عبر واتساب</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => setIsSubmitted(false)}
                        className="w-full sm:w-auto px-5 py-3.5 rounded-xl bg-[#F2EFE9] hover:bg-[#E6E2DA] text-[#111827] text-xs font-bold transition cursor-pointer"
                      >
                        تعديل بيانات الحجز
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="patient-name"
                          className="block text-xs font-bold text-[#111827] mb-2"
                        >
                          الاسم الكامل <span className="text-rose-600">*</span>
                        </label>
                        <input
                          id="patient-name"
                          type="text"
                          required
                          value={patientName}
                          onChange={(e) => setPatientName(e.target.value)}
                          placeholder="مثال: أحمد محمد محمود"
                          className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] text-sm text-[#111827] focus:outline-none focus:border-[#0F5257] focus:bg-white transition"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="patient-phone"
                          className="block text-xs font-bold text-[#111827] mb-2"
                        >
                          رقم الموبايل (يدعم واتساب) <span className="text-rose-600">*</span>
                        </label>
                        <input
                          id="patient-phone"
                          type="tel"
                          required
                          dir="ltr"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="+20 10X XXX XXXX"
                          className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] text-sm text-[#111827] font-mono-tech text-right focus:outline-none focus:border-[#0F5257] focus:bg-white transition"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="service-select"
                          className="block text-xs font-bold text-[#111827] mb-2"
                        >
                          الإجراء أو التخصص المطلوب
                        </label>
                        <select
                          id="service-select"
                          value={selectedService}
                          onChange={(e) => setSelectedService(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] text-sm text-[#111827] focus:outline-none focus:border-[#0F5257] focus:bg-white transition"
                        >
                          {serviceOptions.map((srv) => (
                            <option key={srv} value={srv}>
                              {srv}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label
                          htmlFor="branch-select"
                          className="block text-xs font-bold text-[#111827] mb-2"
                        >
                          الفرع المفضل للزيارة
                        </label>
                        <select
                          id="branch-select"
                          value={selectedBranch}
                          onChange={(e) => setSelectedBranch(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] text-sm text-[#111827] focus:outline-none focus:border-[#0F5257] focus:bg-white transition"
                        >
                          <option value="فرع التجمع الخامس — شارع التسعين الشمالي">
                            فرع التجمع الخامس — شارع التسعين الشمالي
                          </option>
                          <option value="فرع الشيخ زايد — أركان بلازا">
                            فرع الشيخ زايد — أركان بلازا
                          </option>
                          <option value="استشارة أونلاين (فيديو) للقادمين من الخارج">
                            استشارة أونلاين (فيديو) للقادمين من الخارج
                          </option>
                        </select>
                      </div>
                    </div>

                    {/* Time Slot Selector */}
                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-2">
                        الفترة المفضلة للموعد
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {[
                          'الفترة الصباحية / الظهيرة (١٢:٠٠ ظ – ٤:٣٠ م)',
                          'الفترة المسائية (٥:٠٠ م – ٩:٣٠ م)',
                        ].map((slot) => (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => setPreferredTime(slot)}
                            className={`px-4 py-3 rounded-xl border text-xs font-bold transition text-right flex items-center justify-between cursor-pointer ${
                              preferredTime === slot
                                ? 'bg-[#0F5257]/10 border-[#0F5257] text-[#0F5257]'
                                : 'bg-[#FAF8F5] border-[#E6E2DA] text-[#4B5563] hover:bg-[#F2EFE9]'
                            }`}
                          >
                            <span>{slot}</span>
                            <span
                              className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                                preferredTime === slot
                                  ? 'border-[#0F5257] bg-[#0F5257]'
                                  : 'border-[#78716C]'
                              }`}
                            >
                              {preferredTime === slot && (
                                <span className="w-1.5 h-1.5 rounded-full bg-white" />
                              )}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Optional Notes */}
                    <div>
                      <label
                        htmlFor="clinical-notes"
                        className="block text-xs font-bold text-[#111827] mb-2"
                      >
                        ملاحظات إضافية أو استفسار للدكتور حسام (اختياري)
                      </label>
                      <textarea
                        id="clinical-notes"
                        rows={3}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="اكتب أي تفاصيل تود إطلاع الدكتور عليها (مثل: الرغبة في فينير بدون برد، تعويض سن مفقود، إلخ)..."
                        className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] text-sm text-[#111827] focus:outline-none focus:border-[#0F5257] focus:bg-white transition"
                      />
                    </div>

                    {/* Submit & Direct WhatsApp Buttons */}
                    <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                      <button
                        type="submit"
                        className="w-full sm:flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-[#0F5257] hover:bg-[#0A3C40] text-white font-bold text-sm transition shadow-lg shadow-[#0F5257]/20 cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                        <span>تأكيد طلب حجز الموعد</span>
                      </button>

                      <a
                        href={buildWhatsAppLink()}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-4 rounded-xl bg-[#F2EFE9] hover:bg-[#E6E2DA] text-[#111827] font-bold text-sm transition"
                      >
                        <MessageCircle className="w-4 h-4 text-[#0F5257]" />
                        <span>حجز فوري عبر واتساب</span>
                      </a>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
