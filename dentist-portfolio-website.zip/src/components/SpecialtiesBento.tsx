import React, { useState } from 'react';
import { Check, Clock, Shield, Sparkles, ArrowUpLeft, ChevronDown, ChevronUp } from 'lucide-react';
import { SPECIALTIES, SpecialtyItem } from '../data/portfolioData';
import { SpecialtyAnatomyIcon } from './DentalSvgIcons';

interface SpecialtiesBentoProps {
  onBookSpecialty: (specialtyTitle: string, note: string) => void;
}

export const SpecialtiesBento: React.FC<SpecialtiesBentoProps> = ({ onBookSpecialty }) => {
  const [expandedId, setExpandedId] = useState<string | null>('dsd-veneers');

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="specialties" className="py-24 lg:py-32 bg-[#FAF8F5] relative">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
        {/* Section Heading */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-14 border-b border-[#E6E2DA]">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E0F2F1] text-[#0F5257] text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="font-mono-tech uppercase tracking-wider">
                CLINICAL SPECIALTIES // التخصصات العلاجية والتجميلية
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-[2.6rem] font-bold text-[#111827] leading-[1.2] font-heading">
              طب أسنان مجهري يجمع بين{' '}
              <span className="text-[#0F5257]">الهندسة الرقمية والجمال الحيوي</span>
            </h2>
          </div>
          <p className="text-[#4B5563] text-base max-w-md leading-relaxed">
            نعتمد في عيادة د. حسام أشرف بروتوكولات علاجية غير جائرة (Minimally Invasive) تحافظ على
            بنية الأسنان الطبيعية وتضمن عمراً افتراضياً طويلاً للتركيبات.
          </p>
        </div>

        {/* 12-Column Asymmetric Bento Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {SPECIALTIES.map((item: SpecialtyItem, index: number) => {
            // Make the first two cards span 6 columns on lg, and the next four span 6 or 4 columns harmoniously
            const colSpanClass =
              index === 0 || index === 1
                ? 'lg:col-span-6'
                : index === 2 || index === 3
                ? 'lg:col-span-6'
                : 'lg:col-span-6';

            const isExpanded = expandedId === item.id;

            return (
              <div
                key={item.id}
                className={`${colSpanClass} group rounded-2xl bg-white border transition-all duration-300 p-7 sm:p-8 flex flex-col justify-between ${
                  item.featured
                    ? 'border-[#C5A059]/60 shadow-[0_20px_40px_-15px_rgba(15,82,87,0.08)]'
                    : 'border-[#E6E2DA] hover:border-[#0F5257]/40 hover:shadow-[0_20px_40px_-15px_rgba(15,82,87,0.06)]'
                }`}
              >
                <div>
                  {/* Card Top Bar */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-colors ${
                          item.featured
                            ? 'bg-[#0F5257] text-[#FAF8F5]'
                            : 'bg-[#F2EFE9] text-[#0F5257] group-hover:bg-[#0F5257] group-hover:text-white'
                        }`}
                      >
                        <SpecialtyAnatomyIcon type={item.iconType} className="w-7 h-7" />
                      </div>
                      <div>
                        <span className="font-mono-tech text-xs text-[#78716C] block">
                          {item.code}
                        </span>
                        <span className="font-latin text-xs font-medium text-[#0F5257]">
                          {item.titleEn}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold shrink-0 ${
                        item.featured
                          ? 'bg-[#C5A059]/20 text-[#8A6928] border border-[#C5A059]/40'
                          : 'bg-[#F2EFE9] text-[#4B5563]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </div>

                  {/* Title & Summary */}
                  <h3 className="mt-6 text-xl sm:text-2xl font-bold text-[#111827] leading-snug font-heading">
                    {item.titleAr}
                  </h3>
                  <p className="mt-3 text-[#4B5563] text-sm sm:text-base leading-relaxed">
                    {item.summary}
                  </p>

                  {/* Key Metrics Pills */}
                  <div className="mt-5 flex flex-wrap items-center gap-2.5 pt-4 border-t border-[#E6E2DA]/80 text-xs">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FAF8F5] border border-[#E6E2DA] text-[#111827] font-medium">
                      <Clock className="w-3.5 h-3.5 text-[#0F5257]" />
                      <span>المدة: {item.typicalSessions}</span>
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FAF8F5] border border-[#E6E2DA] text-[#111827] font-medium">
                      <Shield className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>العمر الافتراضي: {item.longevity}</span>
                    </div>
                  </div>

                  {/* Expandable Clinical Protocol Section */}
                  <div className="mt-4">
                    <button
                      type="button"
                      onClick={() => toggleExpand(item.id)}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F5257] hover:text-[#0A3C40] transition cursor-pointer"
                    >
                      <span>
                        {isExpanded
                          ? 'إخفاء تفاصيل البروتوكول السريري'
                          : 'استعراض البروتوكول السريري والتقنية المستخدمة'}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>

                    {isExpanded && (
                      <div className="mt-3 p-4 rounded-xl bg-[#FAF8F5] border border-[#E6E2DA] space-y-2.5 animate-fadeIn">
                        <div className="text-xs font-mono-tech text-[#0F5257] font-semibold">
                          TECH // {item.technology}
                        </div>
                        <ul className="space-y-2">
                          {item.clinicalProtocol.map((step, sIdx) => (
                            <li
                              key={sIdx}
                              className="flex items-start gap-2 text-xs sm:text-sm text-[#4B5563]"
                            >
                              <Check className="w-4 h-4 text-[#0F5257] shrink-0 mt-0.5" />
                              <span>{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Footer CTA */}
                <div className="mt-6 pt-4 border-t border-[#E6E2DA] flex items-center justify-between gap-4">
                  <span className="font-mono-tech text-[11px] text-[#78716C] truncate">
                    {item.technology.split(' + ')[0]}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      onBookSpecialty(
                        item.titleAr,
                        `أرغب في حجز موعد بخصوص (${item.titleAr})`
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0F5257]/8 hover:bg-[#0F5257] text-[#0F5257] hover:text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                  >
                    <span>احجز استشارة التخصص</span>
                    <ArrowUpLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
