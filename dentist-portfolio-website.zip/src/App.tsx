import { useState } from 'react';
import {
  Sparkles,
  Calendar,
  ArrowLeft,
  ShieldCheck,
  Award,
  CheckCircle2,
  Menu,
  X,
  Phone,
  MapPin,
} from 'lucide-react';
import { DOCTOR_INFO } from './data/portfolioData';
import { DoctorEmblemSvg } from './components/DentalSvgIcons';
import { BeforeAfterShowcase } from './components/BeforeAfterShowcase';
import { SpecialtiesBento } from './components/SpecialtiesBento';
import { AboutAndJourney } from './components/AboutAndJourney';
import { TestimonialsAndBooking } from './components/TestimonialsAndBooking';

export function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [preselectedService, setPreselectedService] = useState('');
  const [preselectedNote, setPreselectedNote] = useState('');

  const handleBookWithContext = (service: string, note: string) => {
    setPreselectedService(service);
    setPreselectedNote(note);
    const bookingEl = document.getElementById('booking');
    if (bookingEl) {
      bookingEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navLinks = [
    { href: '#cases', label: 'الحالات قبل وبعد' },
    { href: '#specialties', label: 'التخصصات' },
    { href: '#about', label: 'عن الدكتور' },
    { href: '#journey', label: 'خطوات العلاج' },
  ];

  return (
    <div dir="rtl" className="min-h-screen bg-[#FAF8F5] text-[#111827] flex flex-col">
      {/* Single Floating Glassmorphic Navigation Bar */}
      <header className="sticky top-0 z-50 border-b border-[#E6E2DA]/90 bg-[#FAF8F5]/85 backdrop-blur-md">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Right (RTL Start): Doctor Brand Emblem & Title */}
          <a href="#" className="flex items-center gap-3 group">
            <DoctorEmblemSvg className="w-11 h-11 shrink-0 transition-transform duration-300 group-hover:scale-105" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-bold text-[#111827] font-heading tracking-tight">
                  {DOCTOR_INFO.nameAr}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-md bg-[#E0F2F1] text-[#0F5257] font-mono-tech text-[10px] font-bold">
                  BDS, MSc
                </span>
              </div>
              <span className="block text-[11px] text-[#78716C] font-medium">
                استشاري تجميل وزراعة الأسنان الرقمية
              </span>
            </div>
          </a>

          {/* Center: 4 Clean Navigation Links */}
          <nav
            aria-label="التنقل الرئيسي"
            className="hidden md:flex items-center gap-8 text-sm font-semibold text-[#4B5563]"
          >
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-[#0F5257] transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:right-0 after:w-0 after:h-[2px] after:bg-[#C5A059] hover:after:w-full after:transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Left (RTL End): Primary Consultation CTA Pill */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href="#booking"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#0F5257] hover:bg-[#0A3C40] text-white text-sm font-bold transition shadow-md shadow-[#0F5257]/15"
            >
              <Calendar className="w-4 h-4 text-[#C5A059]" />
              <span>احجز استشارتك</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="فتح القائمة"
            className="md:hidden p-2.5 rounded-xl bg-[#F2EFE9] text-[#111827] hover:bg-[#E6E2DA] transition cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Dropdown Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#E6E2DA] bg-[#FAF8F5] px-6 py-5 space-y-4 shadow-xl">
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-base font-bold text-[#111827] hover:text-[#0F5257] py-1.5 border-b border-[#E6E2DA]/60"
                >
                  {link.label}
                </a>
              ))}
            </div>
            <a
              href="#booking"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#0F5257] text-white text-sm font-bold"
            >
              <Calendar className="w-4 h-4 text-[#C5A059]" />
              <span>احجز استشارتك الآن</span>
            </a>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section & Clinical Authority Metrics */}
        <section className="relative pt-10 pb-20 lg:pt-16 lg:pb-28 overflow-hidden">
          {/* Subtle Warm Radial Spotlight */}
          <div
            className="pointer-events-none absolute top-0 left-1/4 w-[650px] h-[650px] rounded-full opacity-40 blur-3xl"
            style={{
              background:
                'radial-gradient(circle, rgba(224,242,241,0.85) 0%, rgba(197,160,89,0.12) 50%, transparent 100%)',
            }}
          />

          <div className="max-w-[1280px] mx-auto px-6 lg:px-8 relative z-10">
            {/* Asymmetric 12-Column Split Grid: 7 Cols Content (Right), 5 Cols Editorial Portrait (Left) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
              {/* 7-Column Typography & Actions (Right Side in RTL) */}
              <div className="lg:col-span-7 space-y-7">
                {/* Clinical Overline Badge */}
                <div className="inline-flex flex-wrap items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E6E2DA] shadow-2xs">
                  <span className="w-2 h-2 rounded-full bg-[#0F5257] animate-pulse-subtle" />
                  <span className="text-xs font-bold text-[#0F5257]">
                    استشاري تجميل وزراعة الأسنان الرقمية
                  </span>
                  <span className="text-[#E6E2DA]">|</span>
                  <span className="font-mono-tech text-[11px] font-semibold text-[#C5A059]">
                    AACD & ITI FELLOW
                  </span>
                </div>

                {/* Main Arabic Display Headline */}
                <h1 className="text-4xl sm:text-5xl lg:text-[3.55rem] font-extrabold text-[#111827] leading-[1.16] font-heading">
                  نحت الابتسامة بدقة الميكروسكوب...{' '}
                  <span className="text-[#0F5257] underline decoration-[#C5A059]/60 decoration-2 underline-offset-8">
                    لتبدو وكأنك وُلدت بها.
                  </span>
                </h1>

                {/* Lead Paragraph */}
                <p className="text-base sm:text-lg lg:text-xl text-[#4B5563] leading-[1.75] max-w-[62ch]">
                  مرحباً بك في العيادة الرقمية والبورتفوليو السريري للدكتور{' '}
                  <strong className="text-[#111827]">حسام أشرف</strong>. نجمع بين تكنولوجيا المسح
                  ثلاثي الأبعاد، عدسات البورسلين السويسرية فائقة الرقة (0.2 مم بدون برد جائر)،
                  والزراعة الفورية الموجهة بالكمبيوتر لمنحك ابتسامة متناغمة تدوم لعقود.
                </p>

                {/* Key Clinical Highlights Checklist */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="flex items-center gap-2.5 text-sm font-semibold text-[#111827]">
                    <CheckCircle2 className="w-4 h-4 text-[#0F5257] shrink-0" />
                    <span>معاينة وتجربة الابتسامة (Mock-up) قبل البدء</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-sm font-semibold text-[#111827]">
                    <CheckCircle2 className="w-4 h-4 text-[#0F5257] shrink-0" />
                    <span>تحضير مجهري يحافظ على مينا الأسنان ١٠٠٪</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-sm font-semibold text-[#111827]">
                    <CheckCircle2 className="w-4 h-4 text-[#0F5257] shrink-0" />
                    <span>زراعة سويسرية فورية بدون جراحة أو غرز</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-sm font-semibold text-[#111827]">
                    <CheckCircle2 className="w-4 h-4 text-[#0F5257] shrink-0" />
                    <span>ضمان طبي رسمي معتمد على جميع التركيبات</span>
                  </div>
                </div>

                {/* Dual Action Bar */}
                <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                  <a
                    href="#booking"
                    className="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-2xl bg-[#0F5257] hover:bg-[#0A3C40] text-white font-bold text-base transition-all shadow-xl shadow-[#0F5257]/20"
                  >
                    <Calendar className="w-5 h-5 text-[#C5A059]" />
                    <span>احجز استشارة تصميم الابتسامة</span>
                  </a>

                  <a
                    href="#cases"
                    className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl bg-white hover:bg-[#F2EFE9] text-[#111827] border border-[#E6E2DA] font-bold text-base transition-all shadow-xs"
                  >
                    <span>استعرض حالات قبل وبعد</span>
                    <ArrowLeft className="w-4 h-4 text-[#0F5257]" />
                  </a>
                </div>

                {/* Trust Micro-Bar */}
                <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-[#78716C]">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#0F5257]" />
                    <span>مواد سويسرية وألمانية أصلية بشهادة منشأ</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#C5A059]" />
                    <span>التجمع الخامس • الشيخ زايد</span>
                  </div>
                </div>
              </div>

              {/* 5-Column Editorial Portrait of Dr. Hossam Ashraf (Left Side in RTL) */}
              <div className="lg:col-span-5 relative">
                {/* Decorative Champagne Brass Architectural Frame Offset */}
                <div className="absolute -inset-3 rounded-[28px] border border-[#C5A059]/35 -rotate-1 pointer-events-none hidden sm:block" />

                <div className="relative rounded-3xl overflow-hidden bg-[#F2EFE9] border border-[#E6E2DA] shadow-[0_25px_50px_-15px_rgba(15,82,87,0.16)]">
                  <div className="aspect-[4/5] w-full relative overflow-hidden">
                    <img
                      src="/images/dr-hossam-portrait.jpg"
                      alt="دكتور حسام أشرف - استشاري تجميل وزراعة الأسنان"
                      className="w-full h-full object-cover object-top"
                    />
                    {/* Subtle gradient vignette at bottom for credential badge legibility */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0D1B1E]/85 via-[#0D1B1E]/15 to-transparent" />
                  </div>

                  {/* Floating Top-Right Verification Pill */}
                  <div className="absolute top-4 right-4 px-3.5 py-2 rounded-xl bg-white/90 backdrop-blur-md border border-[#E6E2DA] shadow-lg flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#C5A059]" />
                    <span className="font-mono-tech text-[11px] font-bold text-[#111827]">
                      DSD CERTIFIED MASTER
                    </span>
                  </div>

                  {/* Bottom Doctor Nameplate Overlay inside Portrait Frame */}
                  <div className="absolute bottom-4 inset-x-4 p-4 sm:p-5 rounded-2xl bg-[#0D1B1E]/85 backdrop-blur-md border border-white/15 text-white">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <span className="font-mono-tech text-[11px] text-[#C5A059] block">
                          {DOCTOR_INFO.nameEn}
                        </span>
                        <h2 className="text-lg sm:text-xl font-bold font-heading">
                          {DOCTOR_INFO.nameAr}
                        </h2>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-[#0F5257] text-emerald-200 text-xs font-bold">
                        +١٢ سنة خبرة
                      </span>
                    </div>
                    <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                      ماجستير التركيبات الثابتة التجميلية (جامعة القاهرة) • عضو الأكاديمية الأمريكية
                      لتجميل الأسنان AACD
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Integrated 4-Column Clinical Authority Metric Bar */}
            <div className="mt-16 lg:mt-20 rounded-2xl bg-white border border-[#E6E2DA] shadow-[0_20px_40px_-15px_rgba(15,82,87,0.06)] p-6 sm:p-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-[#E6E2DA]">
                {DOCTOR_INFO.stats.map((stat, idx) => (
                  <div
                    key={idx}
                    className={`${idx > 0 ? 'pt-5 sm:pt-0 sm:pr-6 lg:pr-8' : ''}`}
                  >
                    <div className="flex items-baseline gap-2">
                      <span
                        dir="ltr"
                        className="font-mono-tech text-3xl sm:text-4xl font-extrabold text-[#0F5257] tabular-nums-tech"
                      >
                        {stat.value}
                      </span>
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-[#F2EFE9] text-[#C5A059]">
                        {stat.unit}
                      </span>
                    </div>
                    <h3 className="mt-2 text-base font-bold text-[#111827] font-heading">
                      {stat.label}
                    </h3>
                    <p className="mt-1 text-xs text-[#78716C]">{stat.subtext}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Before/After Clinical Transformation Showcase */}
        <BeforeAfterShowcase onSelectCaseForBooking={handleBookWithContext} />

        {/* Core Dental Specialties Bento Grid */}
        <SpecialtiesBento onBookSpecialty={handleBookWithContext} />

        {/* About Dr. Hossam, Academic Credentials, Clinic Sanctuary & 4-Step Patient Journey */}
        <AboutAndJourney />

        {/* Verified Patient Stories & Consultation Booking Form */}
        <TestimonialsAndBooking
          preselectedService={preselectedService}
          preselectedNote={preselectedNote}
        />
      </main>

      {/* Architectural Footer */}
      <footer className="bg-[#0D1B1E] text-slate-300 border-t border-white/10">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
            {/* Brand Column (5 Cols) */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-3">
                <DoctorEmblemSvg className="w-10 h-10 shrink-0" />
                <div>
                  <span className="text-lg font-bold text-white font-heading block">
                    {DOCTOR_INFO.nameAr}
                  </span>
                  <span className="font-mono-tech text-xs text-[#C5A059]">
                    {DOCTOR_INFO.nameEn}
                  </span>
                </div>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed max-w-md">
                عيادة واستوديو متخصص في تصميم الابتسامة الرقمي (DSD)، عدسات الإيماكس المجهرية،
                وزراعة الأسنان الموجهة بالكمبيوتر بأعلى معايير الدقة السويسرية.
              </p>
              <div className="flex items-center gap-2 text-xs text-emerald-300 font-mono-tech">
                <Sparkles className="w-4 h-4 text-[#C5A059]" />
                <span>AACD MEMBER • ITI FELLOW • DSD MASTER</span>
              </div>
            </div>

            {/* Quick Links Column (3 Cols) */}
            <div className="md:col-span-3 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                أقسام البورتفوليو
              </h3>
              <ul className="space-y-2.5 text-sm text-slate-400">
                <li>
                  <a href="#cases" className="hover:text-[#C5A059] transition">
                    مختبر حالات قبل وبعد
                  </a>
                </li>
                <li>
                  <a href="#specialties" className="hover:text-[#C5A059] transition">
                    التخصصات السريرية الدقيقة
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-[#C5A059] transition">
                    المؤهلات والزمالات العلمية
                  </a>
                </li>
                <li>
                  <a href="#journey" className="hover:text-[#C5A059] transition">
                    خطوات رحلة المريض (٤ مراحل)
                  </a>
                </li>
                <li>
                  <a href="#booking" className="hover:text-[#C5A059] transition">
                    حجز موعد واستشارة رقمية
                  </a>
                </li>
              </ul>
            </div>

            {/* Clinic Contact Summary (4 Cols) */}
            <div className="md:col-span-4 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                فروع العيادة والتواصل
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                <strong className="text-white block mb-0.5">فرع القاهرة الجديدة:</strong>
                {DOCTOR_INFO.clinicAddressAr}
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                <strong className="text-white block mb-0.5">فرع الشيخ زايد:</strong>
                {DOCTOR_INFO.secondaryBranchAr}
              </p>
              <div className="pt-2 flex items-center gap-2 text-sm font-mono-tech text-[#C5A059]">
                <Phone className="w-4 h-4" />
                <a href={`tel:${DOCTOR_INFO.phoneDisplay.replace(/\s+/g, '')}`} dir="ltr">
                  {DOCTOR_INFO.phoneDisplay}
                </a>
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <p>
              © {new Date().getFullYear()} عيادة {DOCTOR_INFO.nameAr} لتجميل وزراعة الأسنان الرقمية.
              جميع الحقوق محفوظة.
            </p>
            <p className="font-mono-tech text-slate-500">
              PRECISION AESTHETIC & DIGITAL DENTISTRY PORTFOLIO
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
