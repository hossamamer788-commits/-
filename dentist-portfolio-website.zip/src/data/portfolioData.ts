export type CaseCategory = 'all' | 'veneers' | 'implants' | 'gingiva';

export interface ClinicalCase {
  id: string;
  code: string;
  title: string;
  category: Exclude<CaseCategory, 'all'>;
  categoryLabel: string;
  beforeImage: string;
  afterImage: string;
  sessionsCount: string;
  durationDays: string;
  materialUsed: string;
  shadeTransition: string;
  chiefComplaint: string;
  clinicalApproach: string;
  precisionMetrics: {
    label: string;
    value: string;
  }[];
  patientFeedback: string;
  patientInitials: string;
}

export interface SpecialtyItem {
  id: string;
  code: string;
  titleAr: string;
  titleEn: string;
  badge: string;
  summary: string;
  clinicalProtocol: string[];
  technology: string;
  typicalSessions: string;
  longevity: string;
  featured?: boolean;
  iconType: 'veneer' | 'implant' | 'dsd' | 'laser' | 'aligner' | 'micro';
}

export interface JourneyStep {
  stepNumber: string;
  title: string;
  subtitleEn: string;
  description: string;
  durationBadge: string;
  deliverable: string;
}

export interface CredentialItem {
  year: string;
  title: string;
  institution: string;
  location: string;
  code: string;
}

export interface TestimonialItem {
  id: string;
  patientName: string;
  profession: string;
  procedure: string;
  date: string;
  quote: string;
  rating: number;
  caseCode: string;
}

export const DOCTOR_INFO = {
  nameAr: 'د. حسام أشرف',
  nameEn: 'DR. HOSSAM ASHRAF, BDS, MSc',
  titleAr: 'استشاري تجميل وزراعة الأسنان وتصميم الابتسامة الرقمي',
  taglineAr: 'نحت الابتسامة بمعايير الميكروسكوب الجراحي والتناغم الحيوي للوجه',
  bioShort:
    'أكثر من ١٢ عاماً من التخصص الدقيق في إعادة تأهيل الابتسامة المجهري، عدسات البورسلين فائقة الرقة (Ultra-Thin Veneers)، وزراعة الأسنان الفورية الموجهة بالكمبيوتر دون جراحة تقليدية.',
  philosophyQuote:
    '«الابتسامة الناجحة ليست تلك التي تلفت الانتباه لبياضها المصطنع، بل تلك التي تبدو وكأنك وُلدت بها في أبهى صورك؛ متناغمة مع ملامح الوجه، وحركة الشفاه، وصحة اللثة على المدى الطويل.»',
  whatsappNumber: '201098765432',
  phoneDisplay: '+20 109 876 5432',
  clinicAddressAr: 'التجمع الخامس — شارع التسعين الشمالي، ميديكال بارك بريمير، جناح ٣٠٤، القاهرة الجديدة',
  secondaryBranchAr: 'الشيخ زايد — أركان بلازا، المبنى الطبي، العيادة ٢١٢',
  workingHours: 'السبت – الخميس: ١٢:٠٠ ظهراً – ٩:٣٠ مساءً (بموعد مسبق)',
  stats: [
    {
      value: '+12',
      unit: 'عاماً',
      label: 'خبرة سريرية متخصصة',
      subtext: 'في تجميل وزراعة الأسنان المجهري',
    },
    {
      value: '+3,500',
      unit: 'حالة',
      label: 'ابتسامة وزراعة ناجحة',
      subtext: 'موثقة رقمياً بمعايير التصوير الطبي',
    },
    {
      value: '0.2',
      unit: 'مم',
      label: 'دقة العدسات المجهرية',
      subtext: 'بدون برد جائر لطبقة المينا الطبيعية',
    },
    {
      value: '99.4%',
      unit: 'نسبة نجاح',
      label: 'الزراعة الموجهة رقمياً',
      subtext: 'باستخدام غرسات سويسرية وألمانية معتمدة',
    },
  ],
};

export const CLINICAL_CASES: ClinicalCase[] = [
  {
    id: 'case-emax-veneers',
    code: 'CASE // DSD-0194',
    title: 'إعادة تصميم الابتسامة بعدسات الإيماكس المجهرية (Micro-Veneers)',
    category: 'veneers',
    categoryLabel: 'هوليود سمايل وفينير',
    beforeImage: '/images/case-1-before.jpg',
    afterImage: '/images/case-1-after.jpg',
    sessionsCount: 'جلستان فقط',
    durationDays: '٥ أيام عمل',
    materialUsed: 'IPS e.max Press (Ivoclar Vivadent - Switzerland)',
    shadeTransition: 'A3.0 → BL2 Natural Translucent',
    chiefComplaint:
      'فراغات بين الأسنان الأمامية (Diastema)، اصفرار داخلي غير مستجيب للتبييض، وتآكل غير متماثل في الحواف القاطعة.',
    clinicalApproach:
      'تم إجراء مسح ثلاثي الأبعاد وتصميم ابتسامة رقمي (DSD) وتجربة النموذج المؤقت (Mock-up) على فم المريض قبل البدء، ثم تثبيت ١٠ عدسات خزفية فائقة الرقة بسمك 0.3 مم تحت التكبير المجهري مع الحفاظ الكامل على حيوية المينا.',
    precisionMetrics: [
      { label: 'سمك العدسة الخزفية', value: '0.28 mm' },
      { label: 'عدد الوحدات التجميلية', value: '10 فينير علوي' },
      { label: 'نسبة شفافية الحافة القاطعة', value: '96% محاكاة طبيعية' },
    ],
    patientFeedback:
      'كنت متخوفاً جداً من الشكل المصطنع أو برد الأسنان، لكن د. حسام أراني شكل ابتسامتي بالكمبيوتر وعلى أسناني قبل أن يلمس سناً واحداً. النتيجة طبيعية لدرجة أن الجميع يلاحظ إشراقة وجهي دون أن يدركوا أنها عدسات!',
    patientInitials: 'م. عبد الرحمن س. — رائد أعمال',
  },
  {
    id: 'case-full-zirconia-implants',
    code: 'CASE // IMP-0248',
    title: 'تأهيل شامل للفك العلوي بالزراعة الفورية وتركيبات الزيركون متعدد الطبقات',
    category: 'implants',
    categoryLabel: 'زراعة الأسنان الفورية',
    beforeImage: '/images/case-2-before.jpg',
    afterImage: '/images/case-2-after.jpg',
    sessionsCount: '٣ جلسات',
    durationDays: '٧ أيام للمرحلة التجميلية',
    materialUsed: 'Straumann® BLX Implants + 3D Multilayer Zirconia',
    shadeTransition: 'C3 Darkened → OM1 Warm Ivory',
    chiefComplaint:
      'تصبغات شديدة وتركيبات قديمة غير متناسقة مع فقدان ضرسين وتآكل في الإطباق أدى إلى صغر المسافة العمودية للوجه.',
    clinicalApproach:
      'تخطيط جراحي موجه بالأشعة المقطعية ثلاثية الأبعاد (CBCT) لزراعة غرسات تيتانيوم سويسرية بدقة ميكرومترية بدون شق جراحي، متبوعة بتركيبات زيركون متعدد الطبقات يحاكي تدرج اللون الطبيعي للسن من العنق حتى الطرف الشفاف.',
    precisionMetrics: [
      { label: 'دقة الدليل الجراحي الرقمي', value: '± 0.15 mm' },
      { label: 'قوة تحمل الزيركون', value: '1150 MPa' },
      { label: 'توازن خط الابتسامة', value: 'Golden Ratio 1.618' },
    ],
    patientFeedback:
      'استعدت قدرتي على المضغ بثقة تامة واختفى المظهر المرهق الذي كانت تسببه التركيبات القديمة. انضباط المواعيد والتعقيم في عيادة د. حسام يضاهي أرقى المراكز الأوروبية.',
    patientInitials: 'أ. طارق م. — استشاري هندسي',
  },
  {
    id: 'case-laser-gingiva-bonding',
    code: 'CASE // LSR-0312',
    title: 'تجميل اللثة بالليزر لعلاج الابتسامة اللثوية مع الحشوات التجميلية الحيوية',
    category: 'gingiva',
    categoryLabel: 'تجميل اللثة والتركيبات',
    beforeImage: '/images/case-3-before.jpg',
    afterImage: '/images/case-3-after.jpg',
    sessionsCount: 'جلسة واحدة',
    durationDays: '٩٠ دقيقة فقط',
    materialUsed: 'Biolase Diode Laser + Empress Direct Nano-Ceramic',
    shadeTransition: 'A2 → B1 High Luster Enamel',
    chiefComplaint:
      'ظهور مفرط وغير متماثل للثة عند الابتسام (Gummy Smile) مما يجعل الأسنان تبدو قصيرة ومربعة مع كسور دقيقة في الأطراف.',
    clinicalApproach:
      'إعادة رسم محيط اللثة (Gingival Zenith Sculpting) باستخدام ليزر الأنسجة الرخوة بدون نزيف أو غرز جراحية وتحت تخدير موضعي مريح، مع بناء الحواف المتآكلة بتقنية الطبقات المجهري (Biomimetic Layering).',
    precisionMetrics: [
      { label: 'إطالة التاج السريري', value: '+2.4 mm' },
      { label: 'فترة التعافي بعد الليزر', value: '24 ساعة فقط' },
      { label: 'التدخل في بنية السن', value: '0% بدون أي برد' },
    ],
    patientFeedback:
      'في جلسة واحدة فقط تغيرت أبعاد ابتسامتي بالكامل بدون أي ألم أو فترة نقاهة. الاهتمام بأدق تفاصيل تماثل اللثة فوق كل سن كان مبهراً بحق.',
    patientInitials: 'د. سارة ك. — طبيبة صيدلانية',
  },
];

export const SPECIALTIES: SpecialtyItem[] = [
  {
    id: 'dsd-veneers',
    code: 'SPEC // 01',
    titleAr: 'تصميم الابتسامة الرقمي وعدسات الإيماكس (DSD & Micro-Veneers)',
    titleEn: 'Digital Smile Design & Ultra-Thin Porcelain Veneers',
    badge: 'الأكثر طلباً',
    summary:
      'تصميم هندسي ثلاثي الأبعاد لابتسامتك بناءً على ديناميكية الشفاه وأبعاد الوجه، وتنفيذه بعدسات خزفية سويسرية بسمك عدسة العين (0.2 – 0.3 مم) تحافظ على المينا الطبيعية.',
    clinicalProtocol: [
      'جلسة تصوير فوتوغرافي وفيديو استوديو لتحليل حركة الابتسامة أثناء الحديث',
      'تجربة الابتسامة المؤقتة (Trial Smile Mock-up) داخل الفم قبل البدء الفعلي',
      'تثبيت مجهري معزول بالكامل (Rubber Dam Isolation) لضمان ثبات يدوم لأكثر من ١٥ عاماً',
    ],
    technology: '3Shape Trios 5 Scanner + IPS e.max CAD/Press',
    typicalSessions: '٢ – ٣ جلسات',
    longevity: '+15 سنة بضمان سريري',
    featured: true,
    iconType: 'veneer',
  },
  {
    id: 'guided-implants',
    code: 'SPEC // 02',
    titleAr: 'زراعة الأسنان الفورية الموجهة بالكمبيوتر',
    titleEn: 'Computer-Guided Flapless Dental Implants',
    badge: 'بدون جراحة تقليدية',
    summary:
      'تعويض الأسنان المفقودة في جلسة واحدة باستخدام دليل جراحي مطبوع ثلاثي الأبعاد يحدد موضع وزاوية الغرسة بدقة 0.1 مم دون الحاجة لمشرط جراحي أو غرز.',
    clinicalProtocol: [
      'دمج الأشعة المقطعية CBCT مع المسح الضوئي للفم لتحديد كثافة العظم بدقة',
      'استخدام غرسات Straumann® السويسرية و Zimmer® الأمريكية ذات الالتئام السريع',
      'تركيب تعويض مؤقت تجميلي فوري في نفس اليوم للحفاظ على المظهر وشكل اللثة',
    ],
    technology: 'CBCT 3D Navigation + Swiss Titanium SLA® Active',
    typicalSessions: 'جلسة زراعة واحدة (٣٠ دقيقة للغرسة)',
    longevity: 'مدى الحياة مع المتابعة الدورية',
    featured: true,
    iconType: 'implant',
  },
  {
    id: 'laser-gum-aesthetics',
    code: 'SPEC // 03',
    titleAr: 'تجميل وتوريد اللثة بالليزر الضوئي',
    titleEn: 'Laser Gingival Sculpting & Depigmentation',
    badge: 'تعافٍ فوري',
    summary:
      'علاج الابتسامة اللثوية (Gummy Smile) وإزالة تصبغات اللثة الداكنة لاستعادة اللون الوردي الصحي وتناغم ارتفاع اللثة بدقة الليزر دون ألم أو نزيف.',
    clinicalProtocol: [
      'تحديد نقاط الذروة اللثوية (Gingival Zenith) رقمياً لتحقيق تناظر مثالي',
      'تطبيق ليزر الدايود الانتقائي الذي يعقم الأنسجة ويحفز تجدد الكولاجين الحيوي',
    ],
    technology: 'Biolase Epic X Diode Laser 940nm',
    typicalSessions: 'جلسة واحدة (٤٥ دقيقة)',
    longevity: 'نتيجة دائمة ومستقرة',
    iconType: 'laser',
  },
  {
    id: 'biomimetic-restorations',
    code: 'SPEC // 04',
    titleAr: 'التركيبات الرقمية والحشوات التجميلية الحيوية',
    titleEn: 'Biomimetic Restorations & Multilayer Zirconia',
    badge: 'دقة ميكروسكوبية',
    summary:
      'إعادة بناء الأسنان المتهدمة أو المعالجة عصبياً باستخدام حشوات السيراميك المصبوبة (Inlays / Onlays) وتيجان الزيركون متعدد الطبقات تحت تكبير الميكروسكوب الجراحي.',
    clinicalProtocol: [
      'تكبير بصري يصل إلى 16x لضمان انطباق الحواف بدون أي فجوات بكتيرية',
      'استخدام تقنية الربط اللاصق المتقدم (Immediate Dentin Sealing) لمنع الحساسية',
    ],
    technology: 'Carl Zeiss Dental Loupes & Microscope + CAD/CAM Milling',
    typicalSessions: '١ – ٢ جلسة',
    longevity: '١٢ – ٢٠ سنة',
    iconType: 'micro',
  },
  {
    id: 'clear-aligners',
    code: 'SPEC // 05',
    titleAr: 'التقويم الشفاف الرقمي غير المرئي',
    titleEn: '3D Digital Clear Aligners Therapy',
    badge: 'شفاف ١٠٠٪',
    summary:
      'رصف الأسنان المزدحمة وإغلاق المسافات بقوالب شفافة مريحة قابلة للإزالة، مع محاكاة ثلاثية الأبعاد توضح حركة كل سن أسبوعاً بأسبوع قبل بدء العلاج.',
    clinicalProtocol: [
      'مسح ضوئي فوري للفكين بدون مقاسات العجين التقليدية المزعجة',
      'خطة علاجية رقمية تتيح تقليل مدة التقويم بنسبة ٣٥٪ مقارنة بالتقويم المعدني',
    ],
    technology: 'Invisalign® & SmartTrack 3D Digital Aligners',
    typicalSessions: 'متابعة كل ٦ أسابيع',
    longevity: 'ثبات دائم مع المثبت الرقمي',
    iconType: 'aligner',
  },
  {
    id: 'laser-whitening',
    code: 'SPEC // 06',
    titleAr: 'التبييض الكيميائي الضوئي الآمن وعلاج الحساسية',
    titleEn: 'Enamel-Safe Photo-Activated Whitening',
    badge: 'آمن على المينا',
    summary:
      'تفتيح لون الأسنان من ٦ إلى ٨ درجات لونية في جلسة واحدة باستخدام بروتوكول مزدوج مدعم بالفلورايد والنانو هيدروكسي أباتيت لحماية المينا ومنع الحساسية.',
    clinicalProtocol: [
      'عزل كامل للثة والشفاه بطبقة واقية ضوئية قبل تطبيق الجل المنشط',
      'تدعيم سطح المينا بمعادن الكالسيوم الحيوية بعد التبييض لثبات اللمعان',
    ],
    technology: 'Philips Zoom! WhiteSpeed LED + ACP Desensitizer',
    typicalSessions: 'جلسة واحدة (٦٠ دقيقة)',
    longevity: '١ – ٣ سنوات حسب نمط الحياة',
    iconType: 'dsd',
  },
];

export const CREDENTIALS: CredentialItem[] = [
  {
    year: '2018 – الآن',
    title: 'زمالة الأكاديمية الأمريكية لتجميل الأسنان (AACD Member)',
    institution: 'American Academy of Cosmetic Dentistry',
    location: 'الولايات المتحدة الأمريكية',
    code: 'CRED // AACD-US',
  },
  {
    year: '2019',
    title: 'ماجستير الاستعاضة الصناعية والتركيبات الثابتة التجميلية',
    institution: 'كلية طب الفم والأسنان — جامعة القاهرة (القصر العيني)',
    location: 'القاهرة، مصر',
    code: 'CRED // MSC-CU',
  },
  {
    year: '2020',
    title: 'اعتماد تصميم الابتسامة الرقمي (Certified Digital Smile Designer)',
    institution: 'DSD Planning Center — Madrid / São Paulo',
    location: 'مدريد، إسبانيا',
    code: 'CRED // DSD-PRO',
  },
  {
    year: '2021',
    title: 'زمالة الفريق الدولي لزراعة الأسنان (ITI Fellow)',
    institution: 'International Team for Implantology',
    location: 'بازل، سويسرا',
    code: 'CRED // ITI-CH',
  },
];

export const PATIENT_JOURNEY: JourneyStep[] = [
  {
    stepNumber: '01',
    title: 'التشخيص الرقمي والمسح ثلاثي الأبعاد',
    subtitleEn: '3D Intraoral Scan & Facial Analysis',
    description:
      'نستبدل المقاسات التقليدية بمسح ضوئي فائق الدقة خلال ٣ دقائق، مع تصوير فوتوغرافي استوديو للوجه والابتسامة وأشعة مقطعية رقمية لتحليل صحة الأسنان واللثة.',
    durationBadge: 'الجلسة الأولى • ٤٥ دقيقة',
    deliverable: 'ملف ثلاثي الأبعاد كامل للفكين + تقرير تشخيصي شامل',
  },
  {
    stepNumber: '02',
    title: 'تصميم الابتسامة وتجربتها الفعلية (Test-Drive)',
    subtitleEn: 'Digital Smile Design & Live Mock-Up',
    description:
      'نصمم ابتسامتك الجديدة رقمياً، ثم نضع نموذجاً تجميلياً مؤقتاً (Mock-up) على أسنانك مباشرة لتشاهد نفسك في المرآة وتبتسم وتتحدث بها قبل الموافقة على التنفيذ النهائي.',
    durationBadge: 'قبل أي إجراء على الأسنان',
    deliverable: 'معاينة حية للابتسامة على وجهك + اختيار درجة اللون والشكل',
  },
  {
    stepNumber: '03',
    title: 'التنفيذ المجهري غير الجائر',
    subtitleEn: 'Microscopic Precision Execution',
    description:
      'يتم تحضير وتجهيز العدسات أو الغرسات تحت تكبير الميكروسكوب والعدسات المكبرة (Carl Zeiss Loupes) لضمان أقصى درجات الحفاظ على أنسجة السن وراحة تامة تحت التخدير الرقمي.',
    durationBadge: 'أعلى معايير الدقة السويسرية',
    deliverable: 'انطباق حواف ميكروسكوبي (Zero-Gap Margin)',
  },
  {
    stepNumber: '04',
    title: 'التثبيت النهائي وبرنامج الرعاية المستدامة',
    subtitleEn: 'Final Bonding & Lifetime Care Protocol',
    description:
      'تثبيت العدسات أو التركيبات ببروتوكول العزل الكامل، مع تسليم وثيقة الضمان الطبي وجدول المتابعة الدورية المجانية للحفاظ على بريق الابتسامة وصحة اللثة.',
    durationBadge: 'ضمان طبي معتمد',
    deliverable: 'شهادة ضمان المواد الأصلية + متابعة دورية كل ٦ أشهر',
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'rev-1',
    patientName: 'المهندسة نادين الشافعي',
    profession: 'مهندسة ديكور وتصميم داخلي',
    procedure: '١٦ عدسة إيماكس فائقة الرقة (DSD Veneers)',
    date: 'يناير ٢٠٢٥',
    quote:
      'بحكم عملي في التصميم كنت أبحث عن طبيب يمتلك حساً فنياً عالياً ولا يصنع أسناناً تشبه الطباشير. د. حسام أشرف فنان حقيقي؛ اختار لي درجة بياض طبيعية جداً مع شفافية في أطراف الأسنان جعلت ابتسامتي تبدو أصغر بـ ١٠ سنوات وبشكل طبيعي ١٠٠٪.',
    rating: 5,
    caseCode: 'VERIFIED // #DSD-882',
  },
  {
    id: 'rev-2',
    patientName: 'المستشار كريم المنشاوي',
    profession: 'مستشار قانوني دولي',
    procedure: 'زراعة أسنان فورية موجهة بالكمبيوتر + تيجان زيركون',
    date: 'ديسمبر ٢٠٢٤',
    quote:
      'كنت أؤجل زراعة ضرسين منذ سنوات بسبب رهبة الجراحة، وفي عيادة د. حسام تمت الزراعة بالدليل الجراحي الرقمي في أقل من نصف ساعة بدون مشرط أو غرز أو أي تورم في اليوم التالي. دقة واحترافية طبية تدعو للفخر.',
    rating: 5,
    caseCode: 'VERIFIED // #IMP-419',
  },
  {
    id: 'rev-3',
    patientName: 'أ. ياسمين فؤاد',
    profession: 'مديرة تسويق إقليمية (الرياض / القاهرة)',
    procedure: 'تجميل اللثة بالليزر + تبييض ضوئي وحشوات تجميلية',
    date: 'فبراير ٢٠٢٥',
    quote:
      'حضرت خصيصاً من الرياض لإجراء تجميل الابتسامة في إجازة قصيرة لمدة أسبوع. تنظيم المواعيد في العيادة كان دقيقاً بالدقيقة، والنتيجة فاقت كل توقعاتي من أول جلسة بدون أي حساسية.',
    rating: 5,
    caseCode: 'VERIFIED // #LSR-507',
  },
];

export const SHADE_PREVIEW_OPTIONS = [
  {
    code: 'BL1',
    nameAr: 'أبيض لؤلؤي ساطع (Hollywood Bright)',
    nameEn: 'VITA Bleach BL1',
    hexPreview: '#F9FBFD',
    borderHex: '#D8E6F2',
    translucency: 'شفافية حافة قاطعة متوسطة (٨٥٪)',
    recommendedFor: 'للشخصيات الإعلامية ومحبي الابتسامة ناصعة البياض ذات الحضور القوي.',
  },
  {
    code: 'BL2',
    nameAr: 'أبيض طبيعي مشرق (Signature Natural)',
    nameEn: 'VITA Bleach BL2 — الدكتور يوصي به',
    hexPreview: '#F4F4EE',
    borderHex: '#DFDDD2',
    translucency: 'شفافية مينا حيوية عالية (٩٦٪)',
    recommendedFor: 'الدرجة الأكثر طلباً في عيادة د. حسام؛ توازن مثالي بين الإشراق والمظهر الطبيعي غير المصطنع.',
  },
  {
    code: 'BL3',
    nameAr: 'عاجي دافئ متناغم (Soft Warm Ivory)',
    nameEn: 'VITA Bleach BL3',
    hexPreview: '#EFECE1',
    borderHex: '#D8D3C2',
    translucency: 'تدرج لوني دافئ متعدد الطبقات (٩٨٪)',
    recommendedFor: 'مثالي لمن يرغب في تجديد شباب الابتسامة بهدوء تام يحاكي الأسنان الطبيعية غير المبيضة.',
  },
  {
    code: 'A1',
    nameAr: 'طبيعي كلاسيكي حيوي (Biomimetic A1)',
    nameEn: 'VITA Classical A1',
    hexPreview: '#EAE5D5',
    borderHex: '#CFC7B2',
    translucency: 'محاكاة كاملة لتشريح السن الطبيعي (١٠٠٪)',
    recommendedFor: 'مثالي عند تجميل سن واحد أو عدة أسنان لمطابقة الأسنان المجاورة بدقة تامة.',
  },
];
